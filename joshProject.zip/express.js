const express = require('express')
const path = require('path')
const app = express()
const port = 3000
const fs = require('fs')

app.use(express.urlencoded({ extended: false }))

app.get('/login',(req,res)=>{
	//console.log(path.join(__dirname,'login.html'))
	res.sendFile(path.join(__dirname,'login.html'))
})

app.post('/login',(req,res)=>{
	//console.log(req.body)
	res.send(`Your username is ${req.body.email}. Password is ${req.body.password}.`)
})

app.get('/signup',(req,res)=>{
	res.sendFile(path.join(__dirname,'register.html'))
})
app.post('/signup',(req,res)=>{
	if(typeof req.body.firstName !== 'string' || req.body.firstName.trim() === ''){
		res.send('First name is not set')
		return	
	}
	if(typeof req.body.lastName !== 'string' || req.body.lastName.trim() === ''){
		res.send('Last name is not set')
		return	
	}
	if(typeof req.body.email !== 'string' || req.body.email.trim() === ''){
		res.send('Email address is not set')
		return	
	}
	if(typeof req.body.password !== 'string' || req.body.password.trim() === ''){
		res.send('Password is not set')
		return	
	}
	//To check if file already exists
	fs.readFile('data.json',(err, data)=>{
		if(err){
			//It means the file does not exists
			fs.writeFileSync('data.json','[]'); //Trying to create the data.json file with an empty array
		}
		let fileData = fs.readFileSync('data.json',{encoding: 'utf8'}); //Reads the updated file data again
		let existingData = JSON.parse(fileData) //Parse the file data to a json type
		existingData.push(req.body) // Adds the new data into the existing data array
		fs.writeFileSync('data.json',JSON.stringify(existingData)) // Replaces the existing data with the updated data inside the data.json
		res.send(`All information set.`)
	});
})

app.use((req,res)=>{
	res.send('Page not found');
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})